<div class="col-md-12">
    <div class="footer_copyright_part">Copyright © 2019 All Rights Reserved.</div>
</div>
